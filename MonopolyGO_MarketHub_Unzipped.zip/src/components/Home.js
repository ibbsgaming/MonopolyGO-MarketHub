
import React from 'react';

const Home = () => (
  <div>
    <h1>MonopolyGO MarketHub</h1>
    <p>Buy, Sell & Trade Stickers, Slots & Accounts</p>
    <h2>Payment Options:</h2>
    <ul>
      <li>PayPal: <a href="https://paypal.me/ibbsgaming" target="_blank">@ibbsgaming</a></li>
      <li>USDT (BEP20): 0x49097ac3bc99bd318e6373e9a33feb12e8c68c69</li>
    </ul>
    <h3>Submit Proof of Payment</h3>
    <p><a href="https://t.me/Ibbs007" target="_blank">Send on Telegram</a> or use the Google Form link in the listing.</p>
  </div>
);

export default Home;
